﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week4.Data_Access.File_Repository.interfaces
{
    class IFileRepo
{
}
}
