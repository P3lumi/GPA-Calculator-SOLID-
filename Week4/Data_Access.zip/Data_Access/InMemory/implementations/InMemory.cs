﻿using System;
using System.Collections.Generic;
using System.Text;
using Week4.Data_Access.InMemory.interfaces;

namespace Week4.Data_Access.InMemory.implementations
{
    class InMemory:IInMemory
    {
    }
}
