﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week4.Data_Access.InMemory.interfaces
{
    class IInMemory
{

}
}
