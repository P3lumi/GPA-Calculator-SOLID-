﻿using System;
using System.Collections.Generic;
using System.Text;
using Week4.Model;

namespace Week4.Data_Access
{
    public interface ICrud
    {
        void Add(Course _course);
        void Read();
    }
}
